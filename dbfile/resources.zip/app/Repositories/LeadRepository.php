<?php

namespace App\Repositories;

use App\Models\AssignLead;
use App\Models\GlobalModel;
use App\Models\LeadFollowUpModel;
use App\Models\LeadHistory;
use App\Models\leadModel;
use App\Models\Leads;
use App\Models\PaidAmountModel;
use App\Models\SourceModel;
use App\Models\StatusModel;
use App\Models\User;
use App\Repositories\leads\LeadInterface;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Response;

use Illuminate\Support\Facades\Auth;

class LeadRepository implements LeadInterface
{
    public function index()
    {
        $data['users'] = User::whereNotIn('role', ['admin', 'compliance'])->get();
        $data['source']  = SourceModel::all();
        $data['status']  = StatusModel::all();

        $data['leads'] = leadModel::with(['assignleads.user'])->orderby('id', 'desc')->paginate(25);
        if (Auth::user()->role != 'admin') {
            $userId =  Auth::user()->id;

            $data['leads'] = leadModel::whereHas('assignleads', function ($query) use ($userId) {
                $query->where('employee_id', $userId);
            })->with(['assignleads.user'])->orderByRaw('updated_at IS NULL DESC, updated_at DESC')
            ->orderBy('id', 'desc')->paginate(25);
        }
        // GlobalModel::getDataOrderByiDesc('leads');
        return view('admin.leads.list', $data);
    }
    public function assigned()
    {
        // Retrieve source and status data
        $data['source'] = SourceModel::all();
        $data['status'] = StatusModel::all();

        // Get the user ID and role
        $userId = Auth::user()->id;
        $role = Auth::user()->role;

        // Prepare the query
        $query = leadModel::query();

        // If the user is not an admin, filter leads by the assigned employee ID
        if ($role != 'admin') {
            $query->whereHas('assignleads', function ($q) use ($userId) {
                $q->where('employee_id', $userId);
            });
        }

        // Order by updated_at in descending order, with nulls first
        $query->with(['assignleads.user'])
            ->orderByRaw('updated_at IS NULL DESC, updated_at DESC')
            ->orderBy('id', 'desc');

        // Paginate the results
        $data['leads'] = $query->paginate(25);

        // Return the view with the data
        return view('admin.leads.list', $data);
    }

    public function payment()
    {
        $data['leads'] = PaidAmountModel::with('leads')->orderby('paymen_received.id', 'desc')->get();
        return view('admin.leads.payment', $data);
    }
    public function assign(): View
    {
        // get total number of unassign leads
        $data['unassignleadscount'] = Leads::leftjoin('assignleads', 'assignleads.lead_id', 'leads.id')->whereNull('assignleads.lead_id')->count();

        $data['leads'] = GlobalModel::getDataOrderByiDesc('leads');
        $data['users'] = GlobalModel::getDataOrderByiDesc('users', 'role', 'admin', '!=');
        $data['sources'] = GlobalModel::getDataOrderByiDesc('sources');
        return view('admin.leads.assign', $data);
    }
    public function unassignleadcount($data)
    {
        return $count['unassignleadscount'] = Leads::leftjoin('assignleads', 'assignleads.lead_id', 'leads.id')->where('leads.source', $data)->whereNull('assignleads.lead_id')->count();
    }
    public function create(): View
    {
        $data['source']  = SourceModel::all();
        $data['status']  = StatusModel::all();

        return view('admin.leads.create', $data);
    }

    public  function delete($data)
    {
        $type = $data['type'];
        if ($type == 'activate') {
            return  leadModel::where('id', $data['id'])->update(['flag' => 1]);
        }
        if ($type == 'removes') {
            return  PaidAmountModel::where('id', $data['id'])->delete();
        }
        if ($type == 'deactivate') {
            return  leadModel::where('id', $data['id'])->update(['flag' => 0]);
        }


        if ($type == 'approve') {
            return  PaidAmountModel::where('id', $data['id'])->update(['status' => 'Approved', 'approved_or_reject_date' => now()]);
        }
        if ($type == 'declined') {
            return  PaidAmountModel::where('id', $data['id'])->update(['status' => 'Declined', 'approved_or_reject_date' => now()]);
        }

        if ($type == 'remove') {
            return  leadModel::where('id', $data['id'])->delete();
        }
    }

    public  function edit($data)
    {
        $lead['users'] = GlobalModel::getDataOrderByiDesc('users', 'role', 'admin', '!=');
        $lead['source']  = SourceModel::all();
        $lead['status']  = StatusModel::all();
        $lead['lead'] =  leadModel::editfunction($data);


        $lead['leadhistory'] = LeadHistory::join('users', 'users.id', 'lead_history.add_by')->where('lead_history.lead_id', $data)->select('lead_history.*', 'users.name', 'users.role')->orderby('lead_history.id', 'desc')->get();

        //   
        $lead['followup'] = LeadFollowUpModel::join('users', 'users.id', 'leads_followups.add_by')->where('leads_followups.lead_id', $data)->select('leads_followups.*', 'users.name', 'users.role')->orderby('leads_followups.id', 'desc')->get();



        $lead['payment'] = PaidAmountModel::join('users', 'users.id', 'paymen_received.add_by')->select('paymen_received.*', 'users.name', 'users.role')->where('lead_id', $data)->orderby('paymen_received.id', 'desc')->get();

        $query = leadModel::query();
        $role = Auth::user()->role;
        $userId = Auth::user()->id;
        $lead['readonly'] = '';

        // If the user is not an admin, filter leads by the assigned employee ID
        if ($role != 'admin') {
            $lead['readonly'] = 'readonly';

            $query->whereHas('assignleads', function ($q) use ($userId) {
                $q->where('employee_id', $userId);
            });
        }

        // Order by updated_at in descending order, with nulls first
        $query->with(['assignleads.user'])
            ->orderByRaw('updated_at IS NULL DESC, updated_at DESC')
            ->orderBy('id', 'desc');

        $nextOrPrevious = $query->pluck('id')->toArray();
        // Find the current lead's index in the array
        $currentIndex = array_search($data, $nextOrPrevious);

        // Determine the previous and next lead IDs
        $lead['previousLeadId'] = $nextOrPrevious[$currentIndex - 1] ?? $data;
         $lead['nextLeadId'] = $nextOrPrevious[$currentIndex + 1] ?? $data;


        return view('admin.leads.edit', $lead);
    }

    public function store($data)
    {
        $addby =  Auth::user()->id;
        $status = $data['status'];

        $data1['name'] =  $data['name'];
        $data1['phone'] =  $data['phone'];
        $data1['email'] =  $data['email'];
        $data1['status'] =    $status;
        $data1['description'] =  $data['description'];
        $data1['source'] =  $data['source'];
        $data1['funds'] = $data['funds'] ?? '';
        $data1['demate'] =  $data['demate'] ?? '';
        $data1['followup'] =  $data['followup'] ?? '';
        $data1['add_by'] =  $addby;
        $data1['created_at'] = now();
        $data1['unique_id'] = GlobalModel::getlastGFCode('leads');




        $query = leadModel::insertGetId($data1);
        if ($query) {
            if ($data['followup'] != '') {
                LeadFollowUpModel::insert(['lead_id' => $query, 'date' => $data['followup'], 'description' => $data['description'], 'add_by' => $addby, 'created_at' => now(), 'status' =>  $status]);
            }
            return response()->json(['code' => 200, 'message' => 'Lead has been created succussfully!']);
        } else {
            return response()->json(['code' => 401, 'message' => 'Something went wrong!']);
        }
    }

    public function update($data)
    {
        $addby =  Auth::user()->id;
        $status =  $data['status'] ?? '';

        $leadid = $data['user_id'];
        $data1['name'] =  $data['name'];
        $data1['phone'] =  $data['phone'];
        $data1['email'] =  $data['email'];
        $data1['status'] = $status;
        $data1['description'] =  $data['description'] ?? '';
        $data1['source'] =  $data['source'] ?? '';
        $data1['funds'] = $data['funds'] ?? '';
        $data1['demate'] =  $data['demate'] ?? '';
        $data1['updated_at'] = now();
        $getlastFollowUpdate =  leadModel::where('id', $leadid)->first();

        if ($getlastFollowUpdate->followup != $data['followup']) {
            $data1['followup'] = $data['followup'];
        }




        if ($data['employee_id'] != '') {

            $matchThese = ['lead_id' => $leadid];
            AssignLead::updateOrCreate($matchThese, ['employee_id' => $data['employee_id'], 'assign_by' => Auth::user()->id, 'lead_id' => $leadid]);
        }

        if ($getlastFollowUpdate->followup != $data['followup']) {
            LeadFollowUpModel::insert(['lead_id' => $leadid, 'date' => $data['followup'], 'description' => $data['description'], 'add_by' => $addby, 'created_at' => now(), 'status' =>  $status]);
        }
        if ($getlastFollowUpdate->followup == $data['followup'] && $getlastFollowUpdate->description != $data['description']) {
            // then store store descitption
            LeadHistory::insert(['lead_id' => $leadid, 'created_at' => now(), 'description' => $data['description'], 'add_by' => $addby, 'status' =>  $status]);
        }
        if (isset($data['paidamount']) && $data['paidamount'] > 0) {
            PaidAmountModel::insert(['lead_id' => $leadid, 'created_at' => now(), 'status' => 'pending', 'add_by' => $addby, 'payment' => $data['paidamount']]);
        }
        $query = leadModel::where('id', $leadid)->update($data1);
        if ($query) {
            return response()->json(['code' => 200, 'message' =>  'Lead has been updated succussfully!']);
        } else {
            return response()->json(['code' => 401, 'message' => 'Something went wrong!']);
        }
    }

    public function status($data)
    {
        $role = Auth::user()->role;
        $statusOptions = ['today', 'paid', 'modifiedtoday', 'todayfollowup'];

        // Validate role and status data
        if (!in_array($data, $statusOptions)) {
            return abort(404);
        }

        $query = leadModel::with(['assignleads.user']);

        if (Auth::user()->role != 'admin') {
            $userId = Auth::user()->id;
            $query->whereHas('assignleads', function ($query) use ($userId) {
                $query->where('employee_id', $userId);
            });
        }

        // Apply filters based on the status data
        switch ($data) {
            case 'today':
                $query->whereDate('created_at', now());
                break;
            case 'paid':
                $query->where('status', $data);
                break;
            case 'modifiedtoday':
                $query->whereDate('updated_at', now());
                break;
            case 'todayfollowup':
                date_default_timezone_set('Asia/Kolkata');
                $query->whereDate('followup', date('Y-m-d'));
                break;
        }

        $leads['leads'] = $query->orderBy('id', 'desc')->paginate(25);

        return view('admin.leads.list', $leads);
    }



    public function filter($data)
    {
        $query = leadModel::with(['assignleads.user']);

        if (Auth::user()->role != 'admin') {
            $userId = Auth::user()->id;
            $query->whereHas('assignleads', function ($query) use ($userId) {
                $query->where('employee_id', $userId);
            });
        }

        if (isset($data['employee_id'])) {
            $empid = $data['employee_id'];
            $query->whereHas('assignleads', function ($q) use ($empid) {
                $q->whereIn('employee_id', $empid);
            });
        }

        if (isset($data['status'])) {
            $query->whereIn('leads.status', $data['status']);
        }

        if (isset($data['search'])) {
            $query->where(function ($q) use ($data) {
                $q->where('leads.unique_id', 'like', '%' . trim($data['search']) . '%')
                    ->orWhere('leads.phone', 'like', '%' . trim($data['search']) . '%');
            });
        }

        if (isset($data['source'])) {
            $query->whereIn('leads.source', $data['source']);
        }

        if (isset($data['from'])) {
            $query->whereDate('leads.created_at', '>=', $data['from']);
        }

        if (isset($data['to'])) {
            $query->whereDate('leads.created_at', '<=', $data['to']);
        }

        $data['leads'] = $query->orderby('leads.id', 'desc')->paginate(25);

        $table = (string)view('admin.leads.table', $data)->render();
        return response()->json(['code' => 215, 'data' => $table]);
    }
    public function assignstore($data)
    {
        $getLeadsQuery = Leads::leftJoin('assignleads', 'assignleads.lead_id', 'leads.id')
            ->whereNull('assignleads.lead_id');

        if ($data['source'] != null) {
            $getLeadsQuery->where('leads.source', $data['source']);
        }

        $getLeads = $getLeadsQuery->limit($data['count'])->select('leads.*')->get();

        if (!empty($getLeads)) {
            $insertData = [];
            $currentTime = now();
            $assignBy = Auth::user()->id;

            foreach ($getLeads as $leadlist) {
                $insertData[] = [
                    'employee_id' => $data['user_id'],
                    'lead_id' => $leadlist->id,
                    'created_at' => $currentTime,
                    'assign_by' => $assignBy,
                    'status' => 'Pending'
                ];
            }

            // Bulk insert to improve performance
            AssignLead::insert($insertData);
        }

        return response()->json(['code' => 200, 'message' => 'Leads Assign Successfully!']);
    }

    public function donwloadsampleexcel()
    {
        $filePath = public_path('sample/sample-leads.xlsx');
        return Response::download($filePath, 'sample-leads.xlsx', [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ]);
    }
}
