<?php

use Illuminate\Support\Facades\DB;

if (!function_exists('top5sales')) {
    function top5sales()
    {
        return "sasa";

       
    }
}
