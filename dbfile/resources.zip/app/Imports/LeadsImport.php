<?php

namespace App\Imports;

use App\Models\GlobalModel;
use App\Models\leadModel;
use App\Models\SourceModel;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class LeadsImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        $sourceName = $row['source'];
        SourceModel::firstOrCreate(['source' => $sourceName]);
        return new leadModel([
            'unique_id' => GlobalModel::getlastGFCode('leads'),
            'name'      => $row['name'] ?? '',
            'email'     => $row['email'] ?? '',
            'phone'     => $row['phone'] ?? '',
            'source'    => $row['source'] ?? '',
            'city'      => $row['city'] ?? '',
            'status'    => 'Pending',
            'created_at' => now(),
            'updated_at' => null, // Set updated_at to null
        ]);
    }
}
