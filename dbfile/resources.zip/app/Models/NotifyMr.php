<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NotifyMr extends Model
{
    protected $table ='notify_mr'; 
    use HasFactory;
}
