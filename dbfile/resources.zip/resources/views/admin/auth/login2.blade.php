<!doctype html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grow Fortuna</title>
    <link rel="shortcut icon" type="image/png" href="{{ asset('admin/images/logo.webp') }}" />
    <link rel="stylesheet" href="{{asset('adminui/css/styles.min.css')}}" />
    <style>

    </style>
</head>

<body>
    <div class="row mt-5">
        <div class="col-md-7 ">
            <div class="text-center">
                <img src="{{ asset('admin/images/trade.webp') }}" class="w-50" alt="">
            </div>
        </div>
       
        <div class="col-md-4">
            <div class="login-container mt-5">
                <div class="image-container"></div>
                <div class="form-container">
                    <div class="card mb-0">
                        <div class="card-body">
                            <a href="#" class="text-nowrap logo-img text-center d-block py-3 w-100">
                                <img src="{{ asset('admin/images/logo.webp') }}" style="width: 120px;" alt="">
                            </a>
                            <p class="text-center">Grow Fortuna</p>
                            <form method="post" action="{{route('validateUser')}}" id="loginauth">
                                @csrf
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" id="exampleInputEmail1" placeholder="Enter Email" aria-describedby="emailHelp">
                                    <div class="error-message" id="email-error"></div>
                                </div>
                                <div class="mb-4">
                                    <label for="exampleInputPassword1" class="form-label">Password</label>
                                    <input type="password" class="form-control" name="password" placeholder="Enter Password" id="exampleInputPassword1">
                                    <div class="error-message" id="password-error"></div>
                                    <div class="text-success" id="success"></div>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <input type="submit" class="btn btn-primary w-50 py-8 fs-4 mb-4 rounded-2" value="Sign In">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--  Body Wrapper -->

    <script src="{{asset('adminui/libs/jquery/dist/jquery.min.js')}}"></script>
    <script src="{{asset('adminui/libs/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('admin/js/ajax/authvalidation.js')}}"></script>

</body>


</html>