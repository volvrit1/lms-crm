@extends('admin.layout')
@section('content')
<style>
    .table-responsive {
        overflow-x: auto;
    }

    .table {
        width: 100%;
        max-width: 100%;
        margin-bottom: 1rem;
    }

    .table-bordered {
        border: 1px solid #dee2e6;
    }
</style>
<meta name="csrf-token" content="{{ csrf_token() }}">

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


















<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Payment </h4>
                
            </div><!-- end card header -->
            @if ($errors->any())
            <div class="alert alert-danger mt-3">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
            <div class="card-body">
                <div class="live-preview">
                    <div class="table-responsive">
                        <table class="table table-bordered  mb-0">
                            <thead>
                                <tr>
                                    <th>SNO</th>
                                    <th>GF Code</th>
                                    <th>Assign Add By</th>
                                    <th>Payment</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                  
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="appendleads">
                                @if(!empty($leads))
                                @foreach($leads as $keys => $list)
                                <tr>
                                    <th>{{ ++$keys }}</th>
                                    <td>
                                        
                                        @php 
                                            $leadinfo  =DB::table('leads')->where('id', $list->lead_id)->first();
                                        
                                        @endphp
                                        @if(!empty( $leadinfo->id))
                                        
                                        
                                        <a href="{{ url('admin/leads/edit', $leadinfo->id) }}">{{ $leadinfo->unique_id ?? '' }}</a>
                                        
                                        @endif()
                                        
                                        
                                        
                                        </td>
                                    <td>
                                        
                                        @php 
                                            $userinfo  =DB::table('users')->where('id',$list->add_by)->first();
                                        
                                        
                                        @endphp
                                        
                                        
                                        {{  $userinfo->name ?? '' }}  -  {{  $userinfo->role ?? '' }}</td>
                                    <td>{{ $list->payment ?? '' }}</td>
                                    <td> @php
                                            $color = 'warning';
                                            @endphp

                                            @if($list->status =='Approved')
                                            @php
                                            $color = 'success';
                                            @endphp
                                            @elseif($list->status =='Declined')
                                            @php
                                            $color = 'danger';
                                            @endphp
                                            @endif

                                            <span class="btn btn-{{$color}} btn-sm">{{$list->status ?? ''}}</span></br>

                                            @if($list->status !='pending')
                                                <span class="mt-4">
                                                {{ date('d-m-Y', strtotime($list->approved_or_reject_date)) }}
                                              </span>
                                            @endif()
                                        
                                        
                                        </td>

                                          
                                    <td>{{ date('d-m-Y', strtotime($list->created_at)) }}</td>

                                    <td style="align-items: end; text-align:end;">
                                        <div class="d-flex gap-2">
                                           
                                            @if(Auth::user()->role=='admin')

                                        
                                          

                                            <div class="remove">
                                                <button class="btn btn-sm btn-info remove-item-btn" onclick="confirmDelete('{{ $list->id }}','approve')">Approve</button>
                                            </div>
                                            <div class="remove">
                                                <button class="btn btn-sm btn-danger remove-item-btn" onclick="confirmDelete('{{ $list->id }}','declined')">Declined</button>
                                            </div>
                                            <div class="remove">
                                                <button class="btn btn-sm btn-danger remove-item-btn" onclick="confirmDelete('{{ $list->id }}','removes')">Delete</button>
                                            </div>
                                            @endif()

                                           

                                        </div>
                                    </td>
                                </tr>
                                @endforeach

                                @endif
                            </tbody>
                        </table>

                    </div>
                </div>
            </div><!-- end card-body -->
        </div><!-- end card -->
    </div><!-- end col -->
</div>


<script src="{{ asset('admin/js/ajax/leads.js') }}"></script>

<style>
    .table th,

    .table th {
        font-size: 14px;
    }

    .table td {
        font-size: 12px;
    }

    .card-title {
        font-size: 1.5rem;
    }

    .btn {
        padding: 0.25rem 0.5rem;
    }
</style>
@endsection
<script>
    document.getElementById('importForm').addEventListener('submit', function() {
        document.getElementById('processingMessage').style.display = 'block';
    });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


</script>