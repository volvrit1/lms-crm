@extends('admin.layout')

<style>
    .ff-secondary {
        color: white !important;
    }

    .fw-medium {
        color: white !important;

    }

    .text-decoration-underline text-white {
        color: black
    }
</style>
@section('content')

@feature('admin_panel')

<div class="row">
    <div class="col-lg-3 ">
        <!-- card -->
        <div class="card card-animate " style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Total Leads </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$lead_count_all ?? 0}}">{{$lead_count_all ?? 0}}</span></h4>
                        <a href="{{route('leads.all')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->

    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium    text-truncate mb-0"> Today Modified</p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$lead_count_modifiedtoday ?? 0}}">{{$lead_count_modifiedtoday ?? 0}}</span></h4>
                        <a href="{{url('admin/leads/status/modifiedtoday')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->
    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Today Follow-ups </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$lead_count_today_followup ?? 0}}">{{$lead_count_today_followup ?? 0}}</span></h4>
                        <a href="{{url('admin/leads/status/todayfollowup')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->
    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Total Sales </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$topFiveSalesSum ?? 0}}">{{$topFiveSalesSum ?? 0}}</span></h4>
                        <!--<a href="#" class="text-decoration-underline text-white">View </a>-->
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->


</div>


<div class="row">
    <!-- <div class="col-lg-8 d-flex align-items-strech">
        <div class="card w-100">
            <div class="card-body">
                <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">
                    <div class="mb-3 mb-sm-0">
                        <h5 class="card-title fw-semibold">Sales Overview</h5>
                    </div>
                    <div>
                        <select class="form-select">
                            <option value="1">March 2023</option>
                            <option value="2">April 2023</option>
                            <option value="3">May 2023</option>
                            <option value="4">June 2023</option>
                        </select>
                    </div>
                </div>
                <div id="chart"></div>
            </div>
        </div>
    </div> -->
            <div class="col-lg-4 col-md-4">
                <div class="card overflow-hidden">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-9 fw-semibold">Total Users</h5>
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h4 class="fw-semibold mb-3">{{$company_admin ?? 0}}</h4>
                                <div class="d-flex align-items-center mb-3">
                                    <a href="{{url('admin/users/all')}}" class="text-decoration-underline text-dark">View </a>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1 overflow-hidden">
                                <p class="text-uppercase fw-medium text-muted text-truncate mb-0"> Total Risk Assesment </p>
                            </div>

                        </div>
                        <div class="d-flex align-items-end justify-content-between mt-4">
                            <div>
                                <h4 class="fs-22 fw-semibold ff-secondary mb-4 text-dark"><span class="counter-value" data-target="{{$riskcount ?? 0}}">{{$riskcount ?? 0}}</span></h4>
                                <a href="{{route('risk.all')}}" class="text-decoration-underline text-dark">View </a>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <div class="col-lg-4 col-md-4">
                <div class="card card-animate">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1 overflow-hidden">
                                <p class="text-uppercase fw-medium text-muted text-truncate mb-0">Total Service Aggrement </p>
                            </div>

                        </div>
                        <div class="d-flex align-items-end justify-content-between mt-4">
                            <div>
                                <h4 class="fs-22 fw-semibold ff-secondary mb-4 text-dark"><span class="counter-value" data-target="{{$serviceaggrementcount ?? 0}}">{{$serviceaggrementcount ?? 0}}</span></h4>
                                <a href="{{route('serviceagreement.all')}}" class="text-decoration-underline text-dark">View </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
           
</div>
<!-- <div class="row">
    <div class="col-lg-4 d-flex align-items-stretch">
        <div class="card w-100">
            <div class="card-body p-4">
                <div class="mb-4">
                    <h5 class="card-title fw-semibold">Recent Transactions</h5>
                </div>
                <ul class="timeline-widget mb-0 position-relative mb-n5">
                    <li class="timeline-item d-flex position-relative overflow-hidden">
                        <div class="timeline-time text-dark flex-shrink-0 text-end">09:30</div>
                        <div class="timeline-badge-wrap d-flex flex-column align-items-center">
                            <span class="timeline-badge border-2 border border-primary flex-shrink-0 my-8"></span>
                            <span class="timeline-badge-border d-block flex-shrink-0"></span>
                        </div>
                        <div class="timeline-desc fs-3 text-dark mt-n1">Payment received from John Doe of $385.90</div>
                    </li>
                    <li class="timeline-item d-flex position-relative overflow-hidden">
                        <div class="timeline-time text-dark flex-shrink-0 text-end">10:00 am</div>
                        <div class="timeline-badge-wrap d-flex flex-column align-items-center">
                            <span class="timeline-badge border-2 border border-info flex-shrink-0 my-8"></span>
                            <span class="timeline-badge-border d-block flex-shrink-0"></span>
                        </div>
                        <div class="timeline-desc fs-3 text-dark mt-n1 fw-semibold">New sale recorded <a href="javascript:void(0)" class="text-primary d-block fw-normal">#ML-3467</a>
                        </div>
                    </li>
                    <li class="timeline-item d-flex position-relative overflow-hidden">
                        <div class="timeline-time text-dark flex-shrink-0 text-end">12:00 am</div>
                        <div class="timeline-badge-wrap d-flex flex-column align-items-center">
                            <span class="timeline-badge border-2 border border-success flex-shrink-0 my-8"></span>
                            <span class="timeline-badge-border d-block flex-shrink-0"></span>
                        </div>
                        <div class="timeline-desc fs-3 text-dark mt-n1">Payment was made of $64.95 to Michael</div>
                    </li>
                    <li class="timeline-item d-flex position-relative overflow-hidden">
                        <div class="timeline-time text-dark flex-shrink-0 text-end">09:30 am</div>
                        <div class="timeline-badge-wrap d-flex flex-column align-items-center">
                            <span class="timeline-badge border-2 border border-warning flex-shrink-0 my-8"></span>
                            <span class="timeline-badge-border d-block flex-shrink-0"></span>
                        </div>
                        <div class="timeline-desc fs-3 text-dark mt-n1 fw-semibold">New sale recorded <a href="javascript:void(0)" class="text-primary d-block fw-normal">#ML-3467</a>
                        </div>
                    </li>
                    <li class="timeline-item d-flex position-relative overflow-hidden">
                        <div class="timeline-time text-dark flex-shrink-0 text-end">09:30 am</div>
                        <div class="timeline-badge-wrap d-flex flex-column align-items-center">
                            <span class="timeline-badge border-2 border border-danger flex-shrink-0 my-8"></span>
                            <span class="timeline-badge-border d-block flex-shrink-0"></span>
                        </div>
                        <div class="timeline-desc fs-3 text-dark mt-n1 fw-semibold">New arrival recorded
                        </div>
                    </li>
                    <li class="timeline-item d-flex position-relative overflow-hidden">
                        <div class="timeline-time text-dark flex-shrink-0 text-end">12:00 am</div>
                        <div class="timeline-badge-wrap d-flex flex-column align-items-center">
                            <span class="timeline-badge border-2 border border-success flex-shrink-0 my-8"></span>
                        </div>
                        <div class="timeline-desc fs-3 text-dark mt-n1">Payment Done</div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-8 d-flex align-items-stretch">
        <div class="card w-100">
            <div class="card-body p-4">
                <h5 class="card-title fw-semibold mb-4">Recent Transactions</h5>
                <div class="table-responsive">
                    <table class="table text-nowrap mb-0 align-middle">
                        <thead class="text-dark fs-4">
                            <tr>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Id</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Assigned</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Name</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Priority</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Budget</h6>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">1</h6>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-1">Sunil Joshi</h6>
                                    <span class="fw-normal">Web Designer</span>
                                </td>
                                <td class="border-bottom-0">
                                    <p class="mb-0 fw-normal">Elite Admin</p>
                                </td>
                                <td class="border-bottom-0">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="badge bg-primary rounded-3 fw-semibold">Low</span>
                                    </div>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0 fs-4">$3.9</h6>
                                </td>
                            </tr>
                            <tr>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">2</h6>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-1">Andrew McDownland</h6>
                                    <span class="fw-normal">Project Manager</span>
                                </td>
                                <td class="border-bottom-0">
                                    <p class="mb-0 fw-normal">Real Homes WP Theme</p>
                                </td>
                                <td class="border-bottom-0">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="badge bg-secondary rounded-3 fw-semibold">Medium</span>
                                    </div>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0 fs-4">$24.5k</h6>
                                </td>
                            </tr>
                            <tr>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">3</h6>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-1">Christopher Jamil</h6>
                                    <span class="fw-normal">Project Manager</span>
                                </td>
                                <td class="border-bottom-0">
                                    <p class="mb-0 fw-normal">MedicalPro WP Theme</p>
                                </td>
                                <td class="border-bottom-0">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="badge bg-danger rounded-3 fw-semibold">High</span>
                                    </div>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0 fs-4">$12.8k</h6>
                                </td>
                            </tr>
                            <tr>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">4</h6>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-1">Nirav Joshi</h6>
                                    <span class="fw-normal">Frontend Engineer</span>
                                </td>
                                <td class="border-bottom-0">
                                    <p class="mb-0 fw-normal">Hosting Press HTML</p>
                                </td>
                                <td class="border-bottom-0">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="badge bg-success rounded-3 fw-semibold">Critical</span>
                                    </div>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0 fs-4">$2.4k</h6>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> -->
</div>


@endfeature

@if(in_array(Auth::user()->role ,['Manager','BDE','Senior BDE']) )
<div class="row">
    <div class="col-lg-3 ">
        <!-- card -->
        <div class="card card-animate " style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Total Leads </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$lead_count_all ?? 0}}">{{$lead_count_all ?? 0}}</span></h4>
                        <a href="{{route('leads.all')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->

    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium    text-truncate mb-0"> Today Modified</p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$lead_count_modifiedtoday ?? 0}}">{{$lead_count_modifiedtoday ?? 0}}</span></h4>
                        <a href="{{url('admin/leads/status/modifiedtoday')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->
    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Today Follow-ups </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$lead_count_today_followup ?? 0}}">{{$lead_count_today_followup ?? 0}}</span></h4>
                        <a href="{{url('admin/leads/status/todayfollowup')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->
    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Total Sales </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$topFiveSalesSum ?? 0}}">{{$topFiveSalesSum ?? 0}}</span></h4>
                        <!--<a href="#" class="text-decoration-underline text-white">View </a>-->
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->


</div>
@endif()

@if(Auth::user()->role =='Compliance')

<div class="row">
    <div class="col-lg-3 ">
        <!-- card -->
        <div class="card card-animate " style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Total Risk Assesment </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$riskcount ?? 0}}">{{$riskcount ?? 0}}</span></h4>
                        <a href="{{route('risk.all')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->

    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium    text-truncate mb-0"> Total Service Aggrement</p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$serviceaggrementcount ?? 0}}">{{$serviceaggrementcount ?? 0}}</span></h4>
                        <a href="{{route('serviceagreement.all')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->
    <div class="col-lg-3">
        <!-- card -->
        <div class="card card-animate" style="background-color: #5d87ff;border-radius: 34px;height: 158px;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium  text-truncate mb-0"> Exipred Service Aggrement </p>
                    </div>

                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="{{$serviceaggrementexpiry ?? 0}}">{{$serviceaggrementexpiry ?? 0}}</span></h4>
                        <a href="{{route('serviceagreement.expired')}}" class="text-decoration-underline text-white">View </a>
                    </div>

                </div>
            </div><!-- end card body -->
        </div><!-- end card -->

    </div><!-- end col -->



</div>
@endif()

@php
$topFiveSales = DB::table('paymen_received as pr')
    ->join('leads as l', 'pr.lead_id', '=', 'l.id')
    ->join('users as u', 'pr.add_by', '=', 'u.id')
    ->select(
        'pr.add_by', 
        'u.name as user_name', 
        DB::raw('SUM(pr.payment) as total_payment'),
        DB::raw('DATE_FORMAT(pr.approved_or_reject_date, "%Y-%m") as month')
    )
    ->where('pr.status', 'Approved')
    ->groupBy('pr.add_by', 'u.name', DB::raw('DATE_FORMAT(pr.approved_or_reject_date, "%Y-%m")'))
    ->orderBy('total_payment', 'desc')
    ->limit(5)
    ->get();
@endphp
<div class="row">
    <div class="col-md-8">

        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Leader Board</h4>

            </div><!-- end card header -->
            <div class="card">

                <div class="card-body">
                    <div class="live-preview">
                        <div class="table-responsive">
                            <table class="table align-middle table-nowrap mb-0" style=" font-size: 12px;">
                                <thead>
                                    <tr>
                                        <th>SNO</th>
                                        <!-- <th>Company name</th> -->
                                        <th> Name</th>
                                        <th>Payment</th>
                                        <th>Month</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    @if(!empty($topFiveSales))

                                    @foreach($topFiveSales as $key=>$list)

                                    <tr>
                                        <th>{{++$key}}</th>
                                        <td>{{$list->user_name ?? ''}}</td>
                                        <td>{{$list->total_payment ?? ''}}</td>
                                        <td>{{$list->month ?? ''}}</td>




                                    </tr>
                                    @endforeach()
                                    @endif()

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div><!-- end card-body -->
        </div>
    </div>
</div>




@endsection