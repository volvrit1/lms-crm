@extends('admin.layout')
@section('content')
<style>
    table thead {
        background-color: black;
        color: white;
    }

    .error {
        color: red !important;
    }

    th {
        font-weight: bolder;
    }
</style>

<meta name="csrf-token" content="{{ csrf_token() }}">

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="row">

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">{{$status ?? ''}} @if($status =='Pending') Approvals @endif()</h4>
                    <div class="flex-shrink-0">
                        <a href="{{url('admin/users/create')}}" class="btn btn-dark  btn-sm">Add new Employee </a>

                    </div>
                </div><!-- end card header -->

                <div class="card-body">
                    <div class="live-preview">
                        <div class="">
                            <table id="example" class="table align-middle  mb-0" style="font-size:12px;">
                                <thead>
                                    <tr>
                                        <th>Sr No.</th>
                                        <th>Unique Id</th>
                                        <th> Name</th>
                                        <th> Role</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Joinning Date</th>
                                        <th>Address</th>
                                        <!-- <th>License Cost</th> -->
                                        <th>Created On</th>
                                        @if(Auth::user()->role=='admin')
                                        <th>Status</th>
                                        <th>Action</th>
                                        @endif()
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(!empty($users))
                                    @foreach($users as $key=>$list)
                                    <tr>
                                        <th>{{++$key}}</th>
                                        <td>{{$list->unique_id ?? ''}}</td>
                                        <td>{{$list->name ?? ''}}</td>
                                        <td>{{$list->role ?? ''}}</td>
                                        <td>{{$list->email ?? ''}}</td>
                                        <td>{{$list->phone ?? ''}}</td>
                                        <td>{{date('Y-M-d' , strtotime($list->joining_date ))}}</td>
                                        <td>{{$list->registered_office ?? ''}}</td>
                                        <td>{{date('Y-M-d' , strtotime($list->created_at ))}}</td>
                                        @if(Auth::user()->role=='admin')

                                        <td> @if($list->flag==1)

                                            <button class="btn btn-sm " onclick="confirmDelete('{{$list->id}}' ,'deactivate')" style="background-color: green; color:white;">Approved</button>

                                            @else
                                            <button class="btn btn-sm btn-danger" onclick="confirmDelete('{{$list->id}}','activate')"> Approve</button>

                                            @endif()
                                        </td>
                                        <td>

                                            <div class="d-flex gap-2">

                                                @if($list->role =='company_admin')
                                                <!-- <a href="{{url('admin/users/company-admin/mr/'.$list->id)}}" class="btn btn-warning btn-sm">View Mr</a> -->

                                                @endif
                                                <div>
                                                    <button class="btn btn-sm btn-success" data-bs-target="#change_password" data-bs-toggle="modal" onclick="showchangepasswordpopup('{{ $list->id }}', 'users')"><i class="ti ti-key"></i></button>


                                                </div>
                                                <div class="remove">
                                                    <button class="btn btn-sm btn-danger remove-item-btn" onclick="confirmDelete('{{$list->id}}','remove')"><i class=" ti ti-trash"></i></button>
                                                </div>
                                                <div class="edit">
                                                    <a href="{{url('admin/users/edit',$list->id)}}" class="btn btn-sm btn-success edit-item-btn"> <i class="ti ti-edit"></i>
                                                    </a>
                                                </div>

                                            </div>
                                        </td>
                                        @endif()

                                    </tr>
                                    @endforeach()
                                    @endif()

                                </tbody>
                            </table>
                        </div>
                    </div>


                </div><!-- end card-body -->
            </div><!-- end card -->
        </div>
        <!-- end col -->

        <script src="{{asset('admin/js/ajax/usercreate.js')}}"></script>

        <div class="modal fade zoomIn" id="change_password" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-soft-info p-3">
                        <h5 class="modal-title" id="myModalLabel">Update Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="btn-close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="changepassworddata">
                            <span id="changepassworddiv"></span>
                            @csrf()
                            @method('post')
                            <span class="text-danger error" id="commonerror"></span>
                            <span class=" text-success " id="success"></span>
                            <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                                <button type="button" class="btn w-sm btn-light" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn w-sm btn-success " id="delete-record">Update Password</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @endsection

    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js"></script>

    <script>
        function showchangepasswordpopup(id, table) {
            $.ajax({
                url: "{{ url('admin/users/changepassworddiv')}}" + "/" + id + '/' + table,
                type: 'get',
                cache: true,
                contentType: false,
                processData: false,
                success: function(result) {
                    $("#changepassworddiv").html(result);
                },
            })
        }
        $(document).on('submit', '#changepassworddata', function(ev) {
            $('.error').html('');

            ev.preventDefault(); // Prevent browers default submit.
            var formData = new FormData(this);
            var error = false;

            if (error == false) {
                $.ajax({
                    url: "{{ url('admin/users/updatepassword') }} ",
                    type: 'post',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    beforeSend: function() {
                        $(".hstackloader").html('<lord-icon src="https://cdn.lordicon.com/dpinvufc.json" trigger="loop" colors="primary:#4bb543,secondary:#4bb543" style="width:50px;"> </lord-icon>');
                        $(".hstack").css('display', 'none');
                        $(".error").text('');
                    },
                    success: function(result) {
                        if (result.code == 200) {

                            $('#success').html(result.message);
                            setTimeout(() => {
                                window.location.href = window.location.href;

                            }, 1000);

                        } else if (result.code == 401) {
                            $.each(result.message, function(prefix, val) {
                                $('#' + prefix + '_error').text(val[0]);
                            });
                        } else {
                            $('#commonerror').html(result.message);

                        }
                    },
                    error: function(xhr) {
                        $(".hstack").css('display', 'flex');
                    },
                    complete: function() {
                        $(".hstack").css('display', 'flex');
                        $(".hstackloader").text('');
                    },
                })
            }
        })
        
    </script>