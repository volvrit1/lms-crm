<!DOCTYPE html>
<html>
<head>
    <title>Laravel PDF</title>
</head>
<body>
    <h1>{{ $title }}</h1>
    <p>This is a sample PDF generated using Laravel.</p>
</body>
</html>