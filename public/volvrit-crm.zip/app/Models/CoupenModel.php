<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CoupenModel extends Model
{
    protected $table='coupens';
    use HasFactory;
}
