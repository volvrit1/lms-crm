<?php

namespace App\Models\admin\doctor;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DoctorReportModel extends Model
{
    use HasFactory;
    protected $table = 'doctor_report';
}
