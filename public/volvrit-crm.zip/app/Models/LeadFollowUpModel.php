<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadFollowUpModel extends Model
{
    protected $table = 'leads_followups';
    use HasFactory;
}
